# YOLOv8-Object-Detection-with-OpenCV


3) To infer on an image that is stored on your local machine
```
python yolo.py --image-path='/path/to/image/'
```
4) To infer on a video that is stored on your local machine
```
python yolo.py --video-path='/path/to/video/'
```
5) To infer real-time on webcam
```
python yolo.py
```
